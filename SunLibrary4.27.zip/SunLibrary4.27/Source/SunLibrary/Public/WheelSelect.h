// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "WheelSelect.generated.h"

/**
 * Roue de selection personnaliser
 */
UCLASS(meta=(DisplayName="Wheel Selector"))
class SUNLIBRARY_API UWheelSelect : public UUserWidget
{
	GENERATED_BODY()

	DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnChange,int,index);

		virtual bool Initialize();

		virtual FReply NativeOnFocusReceived(const FGeometry& InGeometry, const FFocusEvent& InFocusEvent);

private:

	UPROPERTY()
	int SelectIndex;

	UFUNCTION()
	void BLeftClick();

	UFUNCTION()
	void BRightClick();

protected:

	UPROPERTY()
	FText DisplayText;

	UFUNCTION(BlueprintCallable, meta=(DisplayName="MoveWheel"), Category="Custom")
	void F_MoveWheel(int Value);

	UPROPERTY(meta = (BindWidget))
	class UButton* BLeft;

	UPROPERTY(meta = (BindWidget))
	class UButton* BRight;

	UPROPERTY(meta=(BindWidget))
	class UTextBlock* Text_C;

	UPROPERTY(BlueprintReadOnly, meta=(BindWidget), Category="Input")
	class UButton* BForGamepad;

public:
	
	UFUNCTION(BlueprintCallable, meta=(DisplayName="SetIndex", Keywords="Index"), Category="Custom")
	void F_SetSelectedIndex(int Index);

	UFUNCTION(BlueprintPure, meta = (DisplayName = "GetIndex", Keywords = "Index"), Category="Custom")
	int F_GetSelectedIndex();

	UFUNCTION(BlueprintPure, Category="Custom")
	bool RightIsEnable();

	UFUNCTION(BlueprintPure, Category = "Custom")
	bool LeftIsEnable();

	UFUNCTION(BlueprintCallable, Category="Custom")
	void AddOption(FText Value);

	UPROPERTY(BlueprintAssignable, Category = "Custom")
	FOnChange OnChange;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, AdvancedDisplay, Category="Custom")
	bool bLoop;

	UPROPERTY(EditAnywhere, Category = "Custom")
	TArray<FText> Options;
	
};
